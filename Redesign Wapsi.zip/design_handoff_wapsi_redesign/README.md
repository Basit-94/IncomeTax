# Handoff: Wapsi redesign — "Sunrise/Lilac" light theme, "Navy & Coral" dark theme, Munshi ji mascot

## Overview
A full visual redesign of the Wapsi (वापसी) income-tax prototype (Next.js, Tailwind, lucide-react — repo folder `IncomeTax`). Every rendered surface was redrawn in one new design language and a mascot, **Munshi ji** (the friendly CA), was introduced as the voice of the Agentic assistant and the explainer on every screen. Information architecture, routes, copy and states are unchanged — this is a skin + mascot + interaction-polish pass, not a product change.

## About the design files
The files in this bundle are **design references created in HTML**. They are not production code. Recreate them in the existing codebase (`app/*`, `components/*`, `app/globals.css` + `app/d13.css` tokens, Tailwind utilities, lucide icons) using its established patterns. Replace the Direction 13 tokens in `d13.css` / `globals.css` with the tokens below; keep component structure and i18n keys.

- `Wapsi App Redesign.dc.html` — the canvas with every screen and state (open in a browser; sections 1–10, ids like `4f`, `3g`, `D-c`). This is the primary reference.
- `Wapsi Landing Directions.dc.html` — the public landing page. **Turn 5, option 5a** is the final landing (lilac/tangerine, Munshi ji). Earlier turns are superseded explorations.
- `_kit.js` — the helper functions the canvas was generated with. Useful as a literal spec of button/pill/card/input/mascot markup and values.

## Fidelity
**High-fidelity.** Colours, type, radii, spacing and copy are final. Recreate pixel-close with the codebase's libraries. Two stand-ins to replace: (1) icons are hand-drawn line glyphs — use the equivalent **lucide-react** icon at the same size; (2) **Munshi ji is a vector placeholder** — replace with the final illustration/3D render, keeping the described proportions, animation loop and placements.

## Design tokens

### Light theme (default) — "5a"
| Token | Value | Use |
|---|---|---|
| bg | #F3EEFF | page ground |
| glass | rgba(255,255,255,.62) + border rgba(255,255,255,.95) + backdrop-filter blur(18px) | cards, panels, chips |
| ink | #2A1B4A | primary text, dark cards, ink buttons |
| ink2 | #4A3580 | secondary text, brand word |
| ink3 | #7562A8 | tertiary text, mono labels |
| accent | #FF7A1A | primary buttons, progress, pins, "yes" |
| accentSoft | #FFE3C9 | user bubbles, selected rows, callouts (text #4A2100 / #9A3C00) |
| soft | #FFC08A | eyebrows on ink, question-card border |
| ok / okSoft | #1E9E70 / #DDF5EA (text #0F6B48) | confirmed, refund, pre-validated |
| bad / badSoft | #D9403A / #FBE3E1 (text #A32A24) | errors, open notices |
| warn / warnSoft | #B87A00 / #FFF1D6 (text #8A5A00) | corrections, holds |
| line | rgba(74,53,128,.16) | hairlines, dashed dividers |
| tertiary | #8B6CF0 | "earned/stayed with you" bar slice, blob 2 |
| banner | #1B1140 (text #CDBDFF, dot #5EE6B0) | 28px prototype strip |
| shadow | 0 24px 50px -28px rgba(42,27,74,.35) | glass cards |
| glow | 0 12px 30px -8px rgba(255,122,26,.55) | primary buttons |
| blob1 | radial-gradient(circle at 35% 30%,#FFE3C9,#FF7A1A 60%,#C24F00), 620px, top-right, opacity .55, blur 2px | ambient |
| blob2 | radial-gradient(circle at 40% 35%,#FAF7FF,#CDBDFF 65%,#8B6CF0), 380px, bottom-left, opacity .6 | ambient |
Blobs drift: `@keyframes drift {50%{transform:translate(30px,-20px) scale(1.06)}}` 12–15s ease-in-out infinite.

### Dark theme — "P5 Navy & Coral"
| Token | Value |
|---|---|
| bg | #0B1424 |
| card (ink surfaces, Munshi bubbles, ink buttons) | #14213A |
| glass | rgba(255,255,255,.07), border rgba(255,255,255,.14) |
| ink / ink2 / ink3 | #EEF4FF / #B6C6E6 / #7A8DB3 |
| accent | #FF6B5B — **text on accent = bg (#0B1424)**, not white |
| accentSoft / accentText | #3A1C17 / #FFB3A8 |
| ok / okSoft / okText | #2ECF9A / #0F3329 / #7FEBC6 |
| bad / badSoft / badText | #FF7A7A / #3A1B1B / #FFB0B0 |
| warn / warnSoft / warnText | #E6B03A / #382A0C / #FFDB8C |
| tertiary | #4F8DFF |
| line | rgba(255,255,255,.12) |
| banner | #060C18 |
| blobs | radial(#FFC7BF,#FF6B5B 60%,#8A2E24) / radial(#B6C6E6,#4F8DFF 65%,#1F4AA8), opacity .28/.3 |
Theme toggle keeps the existing `wapsi_theme` key and `html.dark` class. The ITR-V receipt stays paper-white in both themes.

### Typography
- **Outfit** (Google Fonts) 400/500/600/700/800 — everything. Replaces Space Grotesk + Source Serif 4.
- **JetBrains Mono** 400/500/700 — PAN, DIN, revision hashes, small caps labels (11–12px, letter-spacing .02–.16em, uppercase for eyebrows).
- **Caveat** 600/700 — Munshi ji's handwritten notes only ("what this means", pencil notes), 17–24px.
- Scale: h1 84/60/50/40/34/32/30px weight 800, letter-spacing −.03 to −.04em, line-height 1.0–1.05; section titles 22–26px 800; body 15–16px/1.5; secondary 13–14px; captions 12–12.5px; eyebrows 12px 700 uppercase .08em.
- Money: Outfit 800, tabular-nums, letter-spacing −.03em; 34–40px headline, 26–30 card, 18–20 inline; refund in ok green, due in bad red.

### Shape & spacing
- Radii: page cards 24px; tiles 20–22px; inputs/buttons 14px; small chips 999px; mode switch 999px; modals 22–26px.
- Buttons: height 46px (50 for full-width primary, 38 compact), padding 0 20px, 700 14.5px. Kinds: primary (accent, glow), ink (ink bg, bg text), ghost (glass), outline (1.5px ink), danger, ok. Disabled = primary at 45% opacity.
- Pills: 4px 11px, 12px 700, 999px.
- Inputs: 50px, rgba(255,255,255,.8) fill, 1.5px glass border; focus = accent border + 0 0 0 3px rgba(255,122,26,.18); error = bad border + 0 0 0 3px rgba(217,64,58,.15). PAN inputs are mono, 20px, letter-spacing .14em, centred, uppercase.
- Page gutter 40–48px; content max 1180px (1060 on the Hub, 760 onboarding, 720 composer). Section gaps 22px; card padding 18–28px.
- Header: 64px, brand box 150px (Munshi avatar 38px + "Wapsi" 20px 800 ink2 + "वापसी" 11px ink3), then the Agentic/Manual pill switch (38px, active segment = ink bg with a 20px Munshi avatar), language pill, theme circle, citizen chip.

## Munshi ji — the mascot
- **Look:** single egg-shaped head/body (skin #E8A87C, belly highlight #F4C9A8), dark brown hair cap and moustache (#4A2C1A), round wire spectacles in ink (light: #2A1B4A, dark theme: #EEF4FF), wide smile, rosy cheeks (#D9775A @70%), two stub arms — right one waving. Source SVG: `munshi()` in `_kit.js` (viewBox 0 0 120 120).
- **Motion loop (CSS):** `nod` 5s (±5° at the base), `blinkEyes` 4.5s (scaleY .1 at 96%), `wave` 2.6s (right arm −22°/+14°/−12°, origin 96,82). Respect prefers-reduced-motion.
- **Placements:** 38px avatar in the brand box; 34px avatar on every assistant turn and question/review card; 24px avatar beside "what this means" on fact cards; 64–150px hero figure peeking from behind composers (left:−118px, bottom:−4px of a 720px composer) with a dark speech bubble above-left (top:−52px; composer wrapper needs ≥60px top margin); 96px on the OTP card, empty states and "filed" screen; 120px on the Hub hero.
- **Voice:** warm uncle-CA. Explains before asking, "beta", shows working, says "simulated" out loud. Speech bubbles: ink bg, bg text, radius 18/18/18/4, 12px 16px padding, 15px.

## Screens (canvas section → codebase file)
1. **Sign-in** `/signin` — `components/auth/auth-portal.tsx`, `otp-screen.tsx`. 1040px glass card, 2 columns: left ink story (Munshi intro, three checks, vault badge, AY pill), right panel with 4 segmented tabs (38px, active = ink). States 1a–1o: PAN default/error, Sign-up idle/busy/error, With-Doc idle/dragging (accent dashed + ring)/reading (spinner)/success (okSoft)/manual-PAN/error, Demo personas, OTP idle/wrong/verifying (6 boxes 48×56 mono, active box accent border).
2. **Onboarding** — `components/onboarding.tsx`. 760px glass card; header eyebrow "Before we start" + "Quick setup n of 4"; 4-segment accent progress; Munshi 64px + bubble asks the question; choice rows 16px radius, selected = accentSoft + accent border + accent tick. Language grid 3 cols; intent list with detail; situation two groups; mode two; focus 2-col multi + "Choose at least one" in bad; ready summary 3 tiles. Footer Back (ghost) / Continue (primary, disabled at 45%).
3. **Agentic** `/app` — `components/agentic/landing.tsx`, `app-shell.tsx`, `workspace.tsx`, `inspector.tsx`. Landing: pill badge, h1 60px, body 18px max 720, composer (glass 20px radius, mic, primary "Ask →"), 4 round 64px shortcuts. Workspace: 272px sidebar (glass, New chat, search, tools, recent chats with active = accentSoft, account block), status pill (mono, tone by state), transcript max 820px: user bubble accentSoft right-aligned; Munshi bubble ink; activity lines mono ink3 with accent dot at 44px indent; **question card** = glass with 1.5px soft (#FFC08A) border, radius 18/18/18/4, kinds: source (option rows), form (labels+inputs+yes/no+Send), yes/no, file (ink upload + ghost skip), choice (primary highlighted), text (mono input + Answer); **review card** = glass with 1.5px accent border, rows label/mono value, emphasised refund row in ok, footer mono "rev · hash · Simulated", buttons File (primary, flex 1) / Review with CA (ghost) / Not yet (ghost); output card ok border with ITR-V pill; completed state adds the "what next 1–7" strip; failed state disables composer. Inspector: 3 header buttons (accent when open), 320px panel: Progress (check / spinning / dot), Outputs, Sources grouped in 4.
4·Hub. **Portal Hub** `/` — `components/landing.tsx`, `landing-action-grid.tsx`, `lib/landingCards.ts`. Hero (badge pill, h1 50, question 22, Munshi 120), starting-path callout (accentSoft, Caveat line), guest strip (glass) or active-session strip (ink, mint dot, primary CTA), Card 01 (glass with 1.5px accent border, two option tiles: ok-tinted normal filing; dashed accent PDF tile → solid accent + ring when dragging), 6 capability cards (3 cols, glass, CARD nn mono + badge pill + tinted icon square, consolidates footer), persona cards (guests only, tilted −.4/.35/−.25°, accent pin).
4. **Dashboard** — `components/dashboard/*`, `fact-row.tsx`, `headline-channels.tsx`. Personalised block (Munshi 72 + h1 30 + primary CTA + Simple/Full segmented). Tab bar: glass pill 3 tabs, active ink, red count badge. Overview: 3 channel cards (eyebrow, money 34 in tertiary/bad/ok, 5px fill bar at bottom), "where it went" stacked bar 22px with 3px gaps + keys; trail = glass details (closed in Simple, open in Full) with dashed groups and okSoft net row; rail 330px: ink refund card (money 40, mint) or due card with Challan CTA, bank card with Pre-validated / Not pre-validated pill, holds card, refund timeline (accent fill, warn pulsing current). Statement: eyebrow/h1 34/progress callout (accentSoft), dividers with mono label, 2-col board of **fact cards** (glass, accent pin, tilt, CARD nn · date, label 18/700, who 13 ink3, badges, money 30, dashed rule, Caveat "Munshi ji: what this means" toggle; states gated (buttons 45%), ready (ok hint), confirmed (ok border + pill + Change), corrected (warn border + strikeout money + Undo), full (mono "where this came from" + "No, this is wrong ↗")); Full-detail sign-off = ink card with Munshi 56 + primary. Actions: defective-return glass card, notices (badSoft open / glass responded, DIN pill, danger CTA), holds card with rent upload, Munshi note; empty state with Munshi 96.
5. **Wizard** — `components/flow/*`. Stepper glass: "Step n of 5" mono + accent label, 5 bars 7px. Deductions: question cards (avatar 30, worth in accent mono, ink "Yes, claim it"), claimed list. Regime: reasoning callout accentSoft with avatar, two cards (selected = accentSoft + 2px accent, Recommended ok pill), full-width primary Accept. Check: glass table rows 12px, chevron, open row shows info + "FROM FACTS" list, refund row 26 ok. File: idle / 3 staged steps (check → spinner → dot, 420ms each) / done (Munshi 96, receipt id in okSoft) / error (badSoft ladder: Retry, File as simulated, Back) / must-pay-first (Challan primary + Review with CA).
6. **ITR-V** — `ItrVReceipt.tsx`. Unchanged paper-white form; only Print/PDF buttons use ink/ghost.
7. **CA portal** `/ca` — `app/ca/page.tsx`. Header with "Wapsi Professional" + mono pill; login glass card (code + PIN mono 20px, optional stamp fields, primary). Review (worksheet layout): sticky client strip (44px avatar, name + PAN pill + PIN pill, meta line, before/after chip −₹94,118 → ₹0, Save draft ghost + Send review primary); step pills Income ✓ · Deductions ✓ · Regime (accentSoft, current) · Notes; two glass worksheets with 5-column grid `minmax(0,1fr) 110px 130px 150px 110px` — Line · Section pill · Client filed (mono ink3) · CA revised (36px mono input, okSoft + ok border when changed) · Δ (ok pill) — plus total rows; notes card (textarea 84px, stamp line, status pills); sticky 340px rail: ink regime card (New/Old segmented with accent active, two tax tiles, Saves pill, Balance due mint 22px), Client-vs-CA diff (3-col with headers), audit trail (mono times), read-only note.
8. **Reconcile** `/reconcile` — `InteractiveTaxDashboard.tsx`. Row grid 1.6fr/1fr/1fr/auto (label+source, Reported, You say, Confirm/Flag or status pill); tone by status (glass / okSoft / warnSoft); dispute drawer attached below (amount, CBDT feedback code select, reason, Save & recalculate); s.139(9) risk card; ink both-regimes rail with Saves pill; progress bar; Munshi note.
9·Vault. **Tax Vault** — `components/vault/citizen-vault-modal.tsx`. Same structure as codebase: 760px, gradient header (ink→#3A2A6E) with shield square, "AY 2026-27 SECURED" pill, mono name·PAN, sync pill, X; 4 underline tabs (accent underline/text active); KYC: virtual PAN card (ink gradient, saffron PAN), Aadhaar card (tricolour dots, masked number, QR, 139AA line), two contact panels; Banks: rows with PRIMARY REFUND ACCOUNT pill + snapshot 3 tiles; Documents: rows with status pill; Database: engine panel, Sync (ink) / Export (ghost), success toast okSoft, syncing spinner; footer with Munshi avatar line + Close.
9. **Modals** — `components/modals/*`, `dashboard/dispute-modal.tsx`, `ui/language-menu.tsx`. Shell: ink header (42px icon square, title 17/800, subtitle #CDBDFF, X), bg body 22–24px padding, radius 26. Challan 280 (kv rows + amount tile + QR panel + method pills), File return (Munshi 64, summary, declaration checkbox in accent), Notices, Dispute (amount mono input + 4 feedback-code radios), Language menu (glass dropdown, search, 2-col list, selected accentSoft).
10. **Dark mode** — 12 frames showing the P5 mapping applied to sections 1–9 & Vault.

## Interactions & motion
- Glass cards: no hover lift; buttons: opacity .9 on hover, primary keeps glow. Inputs: focus ring as above.
- Munshi loops (nod/blink/wave) always on; composer caret blink 1s steps(1); spinners 0.8s linear; blob drift 12–15s; `pulse` 1.6s on the current timeline dot; onboarding/hub cards no entrance animation needed beyond the existing `rise`.
- Filing stages 420ms each (existing `unit`), dropzone drag adds ring + scale(1.01).
- Fact-card read-gate, Simple/Full behaviour, statuses, error ladders — all unchanged from source; only the visuals above.

## State management
No new state. Theme uses existing `wapsi_theme`; sidebar collapse `wapsi_sidebar_collapsed`; everything else is already in `app/page.tsx`, `app/app/page.tsx`, runs/inspector props.

## Assets
- Fonts: Google Fonts Outfit, JetBrains Mono, Caveat.
- Icons: lucide-react (same icon names as current code).
- Munshi ji: `munshi()` SVG in `_kit.js` as placeholder; final illustration to be supplied.
- Aadhaar card uses true flag colours: saffron #FF9933, white, India green #138808 (dots and gradient wash), both themes.
- No raster images.

## Files in this bundle
- `Wapsi App Redesign.dc.html` — all app screens & states (light) + dark section.
- `Wapsi Landing Directions.dc.html` — landing page; use turn 5 / option **5a**.
- `_kit.js` — generator helpers (literal component specs).
- `support.js` — runtime needed to open the .dc.html files locally.
