# Handoff: Wapsi — mobile UI + sign-in rebuild

## Scope
Two increments on top of the already-implemented redesign (light "5a" tokens, dark "P5", Munshi ji): **(1) the rebuilt sign-in** (desktop + mobile) and **(2) the mobile UI for every screen**. Nothing else in the app changes. Tokens, mascot and desktop layouts are already in the codebase; they are repeated below only as reference.

## About the design files
Design references created in HTML — not production code. Recreate in the existing Next.js / Tailwind / lucide-react codebase (`IncomeTax`) with its established patterns and i18n keys.
- `Wapsi Mobile.dc.html` — the mobile canvas, 390×844 frames, sections M1–M10 (ids `m2a`, `m4c`, `m9b`, `md-e`). Primary reference below the `md` breakpoint. **M2** is the mobile sign-in.
- `Wapsi App Redesign.dc.html` — desktop canvas; only **section 1 (ids 1a–1p)** is in scope here: the rebuilt sign-in. Other sections are already built and are context only.
- `_kit.js` — helper functions the canvases were generated with; a literal spec of button/pill/card/input/mascot markup.

## Fidelity
High-fidelity: colours, type, radii, spacing and copy are final. Icons are hand-drawn stand-ins — use the same-size lucide-react icon. Munshi ji is a vector placeholder — keep placements and sizes, swap in the final illustration.

## Design tokens

### Light theme (default) — "5a"
| Token | Value | Use |
|---|---|---|
| bg | #F3EEFF | page ground |
| glass | rgba(255,255,255,.62) + border rgba(255,255,255,.95) + backdrop-filter blur(18px) | cards, panels, chips |
| ink | #2A1B4A | primary text, dark cards, ink buttons |
| ink2 | #4A3580 | secondary text, brand word |
| ink3 | #7562A8 | tertiary text, mono labels |
| accent | #FF7A1A | primary buttons, progress, pins, "yes" |
| accentSoft | #FFE3C9 | user bubbles, selected rows, callouts (text #4A2100 / #9A3C00) |
| soft | #FFC08A | eyebrows on ink, question-card border |
| ok / okSoft | #1E9E70 / #DDF5EA (text #0F6B48) | confirmed, refund, pre-validated |
| bad / badSoft | #D9403A / #FBE3E1 (text #A32A24) | errors, open notices |
| warn / warnSoft | #B87A00 / #FFF1D6 (text #8A5A00) | corrections, holds |
| line | rgba(74,53,128,.16) | hairlines, dashed dividers |
| tertiary | #8B6CF0 | "earned/stayed with you" bar slice, blob 2 |
| banner | #1B1140 (text #CDBDFF, dot #5EE6B0) | 28px prototype strip |
| shadow | 0 24px 50px -28px rgba(42,27,74,.35) | glass cards |
| glow | 0 12px 30px -8px rgba(255,122,26,.55) | primary buttons |
| blob1 | radial-gradient(circle at 35% 30%,#FFE3C9,#FF7A1A 60%,#C24F00), 620px, top-right, opacity .55, blur 2px | ambient |
| blob2 | radial-gradient(circle at 40% 35%,#FAF7FF,#CDBDFF 65%,#8B6CF0), 380px, bottom-left, opacity .6 | ambient |
Blobs drift: `@keyframes drift {50%{transform:translate(30px,-20px) scale(1.06)}}` 12–15s ease-in-out infinite.

### Dark theme — "P5 Navy & Coral"
| Token | Value |
|---|---|
| bg | #0B1424 |
| card (ink surfaces, Munshi bubbles, ink buttons) | #14213A |
| glass | rgba(255,255,255,.07), border rgba(255,255,255,.14) |
| ink / ink2 / ink3 | #EEF4FF / #B6C6E6 / #7A8DB3 |
| accent | #FF6B5B — **text on accent = bg (#0B1424)**, not white |
| accentSoft / accentText | #3A1C17 / #FFB3A8 |
| ok / okSoft / okText | #2ECF9A / #0F3329 / #7FEBC6 |
| bad / badSoft / badText | #FF7A7A / #3A1B1B / #FFB0B0 |
| warn / warnSoft / warnText | #E6B03A / #382A0C / #FFDB8C |
| tertiary | #4F8DFF |
| line | rgba(255,255,255,.12) |
| banner | #060C18 |
| blobs | radial(#FFC7BF,#FF6B5B 60%,#8A2E24) / radial(#B6C6E6,#4F8DFF 65%,#1F4AA8), opacity .28/.3 |
Theme toggle keeps the existing `wapsi_theme` key and `html.dark` class. The ITR-V receipt stays paper-white in both themes.

### Typography
- **Outfit** (Google Fonts) 400/500/600/700/800 — everything. Replaces Space Grotesk + Source Serif 4.
- **JetBrains Mono** 400/500/700 — PAN, DIN, revision hashes, small caps labels (11–12px, letter-spacing .02–.16em, uppercase for eyebrows).
- **Caveat** 600/700 — Munshi ji's handwritten notes only ("what this means", pencil notes), 17–24px.
- Scale: h1 84/60/50/40/34/32/30px weight 800, letter-spacing −.03 to −.04em, line-height 1.0–1.05; section titles 22–26px 800; body 15–16px/1.5; secondary 13–14px; captions 12–12.5px; eyebrows 12px 700 uppercase .08em.
- Money: Outfit 800, tabular-nums, letter-spacing −.03em; 34–40px headline, 26–30 card, 18–20 inline; refund in ok green, due in bad red.

### Shape & spacing
- Radii: page cards 24px; tiles 20–22px; inputs/buttons 14px; small chips 999px; mode switch 999px; modals 22–26px.
- Buttons: height 46px (50 for full-width primary, 38 compact), padding 0 20px, 700 14.5px. Kinds: primary (accent, glow), ink (ink bg, bg text), ghost (glass), outline (1.5px ink), danger, ok. Disabled = primary at 45% opacity.
- Pills: 4px 11px, 12px 700, 999px.
- Inputs: 50px, rgba(255,255,255,.8) fill, 1.5px glass border; focus = accent border + 0 0 0 3px rgba(255,122,26,.18); error = bad border + 0 0 0 3px rgba(217,64,58,.15). PAN inputs are mono, 20px, letter-spacing .14em, centred, uppercase.
- Page gutter 40–48px; content max 1180px (1060 on the Hub, 760 onboarding, 720 composer). Section gaps 22px; card padding 18–28px.
- Header: 64px, brand box 150px (Munshi avatar 38px + "Wapsi" 20px 800 ink2 + "वापसी" 11px ink3), then the Agentic/Manual pill switch (38px, active segment = ink bg with a 20px Munshi avatar), language pill, theme circle, citizen chip.

## Munshi ji — the mascot
- **Look:** single egg-shaped head/body (skin #E8A87C, belly highlight #F4C9A8), dark brown hair cap and moustache (#4A2C1A), round wire spectacles in ink (light: #2A1B4A, dark theme: #EEF4FF), wide smile, rosy cheeks (#D9775A @70%), two stub arms — right one waving. Source SVG: `munshi()` in `_kit.js` (viewBox 0 0 120 120).
- **Motion loop (CSS):** `nod` 5s (±5° at the base), `blinkEyes` 4.5s (scaleY .1 at 96%), `wave` 2.6s (right arm −22°/+14°/−12°, origin 96,82). Respect prefers-reduced-motion.
- **Placements:** 38px avatar in the brand box; 34px avatar on every assistant turn and question/review card; 24px avatar beside "what this means" on fact cards; 64–150px hero figure peeking from behind composers (left:−118px, bottom:−4px of a 720px composer) with a dark speech bubble above-left (top:−52px; composer wrapper needs ≥60px top margin); 96px on the OTP card, empty states and "filed" screen; 120px on the Hub hero.
- **Voice:** warm uncle-CA. Explains before asking, "beta", shows working, says "simulated" out loud. Speech bubbles: ink bg, bg text, radius 18/18/18/4, 12px 16px padding, 15px.

## Part 1 — Sign-in rebuild (desktop, `/signin`)
Files: `components/auth/auth-portal.tsx`, `otp-screen.tsx`, `app/ca/page.tsx` (login half). **Rebuilt: the four tabs (Sign In / Sign Up / With Doc / Demo) are gone.**
   - **Two tabs only:** `Citizen` (icon user) and `Chartered Accountant` (icon award). Segmented control, 40px, radius 16/12, active = ink bg + bg text. The old "Are you a CA?" strip is removed — the CA login *is* the second tab (review code + PIN mono 20px, optional stamp: name + membership no. in a 2-col grid, primary "Open client return →", "No code? Load a demo review" link). On success route to `/ca` review.
   - **Citizen tab:** title "Sign in with your PAN", PAN input (mono 20px, 54px, centred, uppercase), primary "Sign in & continue →" full width, then **sign-up as a link**: "New here? *Create your account with your PAN*" (accent, underlined, centred, 13.5px) → swaps the panel to the Create-account view (1d–1f: idle / submitting spinner / invalid PAN) with a "‹ Back to sign in" text button on top. Then an **OR** hairline rule (mono label) and the **"Or sign in with a document"** row: dashed 1.5px ink3 border, radius 16, 40px ink icon square (upload), title 14/700, sub "Munshi ji reads the PAN off your Form 16 or AIS — no typing.", chevron in accent → swaps the panel to the document view (1g–1o: idle dropzone / dragging (accent dashed + ring) / reading / success (okSoft) / manual-PAN fallback / unreadable). Below: "QUICK DEMO PAN" mono label + three mono pills (Sunita/Rakesh/Priya) — the only place demo personas remain on this page; the full demo-citizen list (1p) is reached from the landing/Hub "Try a demo citizen".
   - Footer on every panel: mono 11px "🔒 Bank-grade encryption" (ok) · "Authorised users only" (ink3).
   - Left column unchanged: ink story with Munshi ji intro, three checks, vault badge, AY pill. Whole card 1040px, 2 cols (1fr / 1.05fr), radius 28.
   - OTP (1l–1n) unchanged.
   - State: `authView: 'citizen' | 'ca' | 'signup' | 'doc'`; `citizen`/`ca` are the tabs, `signup`/`doc` are sub-views entered from links and exited with Back. Existing handlers (`handleSignIn`, `handleSignUp`, doc ingestion, CA code/PIN verify) are reused as-is.

## Mobile (`Wapsi Mobile.dc.html`) — below `md` (≤ 767px)
Frame 390×844, safe areas: 54px status, 22px prototype banner, 34px home-indicator zone. Same tokens; type scale steps down one notch (h1 44/40/36/26/24, section titles 19, body 14–15, captions 12). All frames are tap-target ≥ 44px.

**Global patterns**
- **Header** 56px: back circle (36px glass) *or* hamburger, title 16/800 (ellipsis), right slot for language/theme circles, citizen chip, or inspector button. Brand box only on landing/home/hub.
- **Manual mode → bottom tab bar** (M5, M6): Overview · Statement · Actions · Vault, 20px icons + 11px labels, active = accent, red count badge on Actions; bar bg rgba(243,238,255,.9) + blur, top hairline, 26px bottom padding.
- **Agentic mode:** no sidebar. Hamburger opens a **left drawer** (300px, bg, 60px top pad): New chat, Wapsi tools, Recent chats (active = accentSoft), a **Mode** section with the full-width Agentic|Manual switch + one-line note, then the account row with theme toggle. The **inspector** is a **bottom sheet** (62% height) with a Progress / Outputs / Sources segmented control. The workspace header carries a compact Agentic|Manual pill (36px, 11.5px) between the title and the inspector button.
- **Composer** pinned above the home indicator inside a gradient fade (`linear-gradient(to top, bg 70%, transparent)`), 18px radius, mic + 42px accent send square.
- **Pinned primary CTA** — every form/wizard screen pins its primary (50px, full width) in the same fade strip; secondary actions stack under it (44px ghost).
- **Modals → bottom sheets** (M9): grab handle 44×5, radius 28 top, header = 40px ink icon square (or Munshi 40px), title 17/800, sub 12, X; body 20px padding; heights 62–86%. Scrim rgba(27,17,64,.55).
- **Segmented controls** replace tabs everywhere (36–38px, radius 14/11).
- Ambient blobs kept at the same opacity; Munshi ji sizes: 34 brand, 28 chat avatar, 52–56 onboarding/intro strip, 72–84 hero/OTP, 96–120 empty/landing.

**Screens**
- **M1 Landing** — pill, h1 44, body, Munshi 112 peeking over the composer (absolute, left −8 / top −96) with bubble, shortcut chips (wrap, centred), "three things I check" glass strip.
- **M2 Sign-in** — Munshi intro strip (ink, 56px mascot) → Citizen | Chartered Accountant segmented → same structure as desktop: PAN → "New here? Create your account" link → OR → dashed document row; CTA pinned. Sub-views (Create account, Document) open with "‹ Back to sign in". OTP: 6 boxes 46×56.
- **M3 Onboarding** — one question per screen, 5px progress bar under header, Munshi 52 + bubble, h1 26, choice rows 14px radius, 2-col grid for languages/focus, Continue pinned (disabled at 45%).
- **M4 Agentic** — home (mode switch centred under header, h1 40, Munshi 120, chips, pinned composer); workspace states (status pill, user/Munshi bubbles 86% max, activity lines at 36px indent, question card 1.5px soft border, review card accent border with stacked buttons, completed "what next" chips wrap, failed disables composer); drawer; inspector sheet.
- **M5 Hub** — hero + Munshi 72, ink session strip, Card 01 with two stacked option tiles, capability grid 2 cols (m5b scrolled), bottom tab bar.
- **M6 Dashboard** — Overview: personalised glass block, channel rows (eyebrow + % mono left, money 26 right, 4px bottom fill), ink refund card, trail row; Priya: holds card + vertical timeline. Statement: progress callout, fact cards single-column, untilted, padding 14/16. Actions: defective card, notice cards, empty state Munshi 110.
- **M7 Wizard** — stepper under header (5 bars 5px), deductions question cards with Yes/No pair, regime cards as rows (money right), check table, File states with stacked pinned actions.
- **M8** — Reconcile rows stack Reported / You say with inline dispute drawer, ink live-regime strip on top; CA login; CA review with before/after chip + Income/Deductions/Regime/Notes segmented + compact worksheet rows (client value left, editable CA input 130px right).
- **M9 Sheets** — Vault (underline tabs, PAN card, tricolour Aadhaar card), Challan 280 (QR 130), File return (Munshi header), Dispute, Language.
- **M10 Dark** — P5 mapping, tab bar bg rgba(11,20,36,.92).

Tailwind: use the existing `md:` breakpoint; desktop layouts from sections 1–9 apply at `md` and up, mobile patterns above below it. Drawer/sheet/tab bar are new components: `MobileDrawer`, `BottomSheet`, `MobileTabBar` under `components/mobile/`.

## Interactions & motion
- Buttons opacity .9 on hover; inputs focus ring as in tokens. Munshi loops (nod/blink/wave) always on; spinners 0.8s linear; blob drift 12–15s; dropzone drag adds ring + scale(1.01).
- Mobile drawer slides in 220ms ease-out with scrim fade; bottom sheets slide up 260ms; tab bar is static. Respect prefers-reduced-motion.

## State management
Sign-in: new `authView: 'citizen' | 'ca' | 'signup' | 'doc'` local state in `auth-portal.tsx`; existing handlers reused. Mobile: drawer/sheet open flags are local UI state; theme (`wapsi_theme`), sidebar and run state unchanged.

## Files in this bundle
- `Wapsi Mobile.dc.html` — all mobile screens (M1–M10) incl. dark twins.
- `Wapsi App Redesign.dc.html` — desktop canvas; section 1 = rebuilt sign-in (other sections already implemented).
- `_kit.js`, `support.js` — helpers / runtime to open the .dc.html files locally.
